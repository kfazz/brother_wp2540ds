TeamE, rfka01

Typewriter with a display and a floppy disk drive.